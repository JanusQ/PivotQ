/******************************************************************************
Copyright 2019 The Regents of the University of California.
All Rights Reserved.

Permission to copy, modify and distribute any part of this Software for
educational, research and non-profit purposes, without fee, and without
a written agreement is hereby granted, provided that the above copyright
notice, this paragraph and the following three paragraphs appear in all
copies.

Those desiring to incorporate this Software into commercial products or
use for commercial purposes should contact the:
Office of Innovation & Commercialization
University of California, San Diego
9500 Gilman Drive, Mail Code 0910
La Jolla, CA 92093-0910
Ph: (858) 534-5815
FAX: (858) 534-7345
E-MAIL: invent@ucsd.edu

IN NO EVENT SHALL THE UNIVERSITY OF CALIFORNIA BE LIABLE TO ANY PARTY FOR
DIRECT, INDIRECT, SPECIAL, INCIDENTAL, OR CONSEQUENTIAL DAMAGES, INCLUDING
LOST PROFITS, ARISING OUT OF THE USE OF THIS SOFTWARE, EVEN IF THE UNIVERSITY
OF CALIFORNIA HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

THE SOFTWARE PROVIDED HEREIN IS ON AN "AS IS" BASIS, AND THE UNIVERSITY OF
CALIFORNIA HAS NO OBLIGATION TO PROVIDE MAINTENANCE, SUPPORT, UPDATES,
ENHANCEMENTS, OR MODIFICATIONS. THE UNIVERSITY OF CALIFORNIA MAKES NO
REPRESENTATIONS AND EXTENDS NO WARRANTIES OF ANY KIND, EITHER IMPLIED OR
EXPRESS, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY OR FITNESS FOR A PARTICULAR PURPOSE, OR THAT THE USE OF THE
SOFTWARE WILL NOT INFRINGE ANY PATENT, TRADEMARK OR OTHER RIGHTS.
******************************************************************************/

#include "potential/lj/lj.h"

/**
 * @file lj.cpp
 * @brief Contains the functions definition for the LennardJones class
 */

/**
 * @namespace lj
 * @brief Encloses the functions related to classical lennard-jones.
 */
namespace lj {

std::vector<size_t> LennardJones::GetIsLocal() { return islocal_; }
std::vector<std::string> LennardJones::GetMonIds() { return mon_id_; }
std::vector<size_t> LennardJones::GetNumAtomsVector() { return num_atoms_; }
std::vector<std::pair<std::string, size_t> > LennardJones::GetMonTypeCount() { return mon_type_count_; }
bool LennardJones::GetDoGrads() { return do_grads_; }
std::vector<double> LennardJones::GetBox() { return box_; }
std::vector<double> LennardJones::GetBoxAbc() { return box_ABCabc_; }
std::vector<double> LennardJones::GetBoxInverse() { return box_inverse_; }
std::vector<double> LennardJones::GetSystemLennardJonesField() { return sys_phi_; }
std::vector<double> LennardJones::GetInternalLennardJonesField() { return phi_; }
std::vector<double> LennardJones::GetSystemXyz() { return sys_xyz_; }
std::vector<double> LennardJones::GetInternalXyz() { return xyz_; }
std::vector<double> LennardJones::GetInternalGrads() { return grad_; }
std::vector<double> LennardJones::GetSystemGrads() { return sys_grad_; }
std::vector<double> LennardJones::GetSystemLjLongRange() { return sys_lj_long_range_; }
std::vector<double> LennardJones::GetInternalLjLongRange() { return lj_long_range_; }
std::vector<double> LennardJones::GetVirial() { return virial_; }
std::vector<size_t> LennardJones::GetIsLocalAtom() { return islocal_atom_; }
std::vector<int> LennardJones::GetUserFFTGrid() { return user_fft_grid_; }
double LennardJones::GetCutoff() { return cutoff_; }

void LennardJones::Initialize(const std::vector<double> sys_ljchg, const std::vector<double> &sys_xyz,
                              const std::vector<std::string> &mon_id, const std::vector<size_t> &num_atoms,
                              const std::vector<std::pair<std::string, size_t> > &mon_type_count,
                              const std::vector<size_t> &islocal, const bool do_grads, const std::vector<double> &box) {
#ifdef DEBUG
    std::cerr << std::scientific << std::setprecision(10);
    std::cerr << "\nEntering " << __func__ << " in " << __FILE__ << std::endl;

    std::cerr << "Sys Xyz:\n";
    for (size_t i = 0; i < sys_ljchg.size(); i++) {
        std::cerr << sys_ljchg[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "Sys Xyz:\n";
    for (size_t i = 0; i < sys_xyz.size(); i++) {
        std::cerr << sys_xyz[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "mon_id:\n";
    for (size_t i = 0; i < mon_id.size(); i++) {
        std::cerr << mon_id[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "num_atoms:\n";
    for (size_t i = 0; i < num_atoms.size(); i++) {
        std::cerr << num_atoms[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "mon_type_count:\n";
    for (size_t i = 0; i < mon_type_count.size(); i++) {
        std::cerr << " { " << mon_type_count[i].first << " , " << mon_type_count[i].second << " } , ";
    }
    std::cerr << std::endl;

    std::cerr << "islocal:\n";
    for (size_t i = 0; i < islocal.size(); i++) {
        std::cerr << islocal[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "box:\n";
    for (size_t i = 0; i < box.size(); i++) {
        std::cerr << box[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "doGrads = " << do_grads << std::endl;
#endif

    sys_xyz_ = sys_xyz;
    islocal_ = islocal;
    mon_id_ = mon_id;
    num_atoms_ = num_atoms;
    mon_type_count_ = mon_type_count;
    do_grads_ = do_grads;
    do_field_ = false;
    box_ = box;
    box_ABCabc_ = box.size() ? BoxVecToBoxABCabc(box) : std::vector<double>{};
    box_inverse_ = box.size() ? InvertUnitCell(box) : std::vector<double>{};
    use_pbc_ = box.size();
    natoms_ = sys_xyz.size() / 3;
    size_t natoms3 = 3 * natoms_;
    phi_ = std::vector<double>(natoms_, 0.0);
    xyz_ = std::vector<double>(natoms3, 0.0);
    grad_ = std::vector<double>(natoms3, 0.0);
    virial_ = std::vector<double>(9, 0.0);
    sys_grad_ = std::vector<double>(natoms3, 0.0);
    sys_lj_long_range_ = sys_ljchg;
    lj_long_range_ = std::vector<double>(natoms_, 0.0);
    sys_phi_ = std::vector<double>(natoms_, 0.0);
    islocal_atom_ = std::vector<size_t>(natoms_, 0);

    if (!mpi_initialized_) {
        world_ = 0;
        proc_grid_x_ = 1;
        proc_grid_y_ = 1;
        proc_grid_z_ = 1;
    }

    user_fft_grid_ = std::vector<int>{};

    ReorderData();

#ifdef DEBUG
    std::cerr << std::scientific << std::setprecision(10);
    std::cerr << "\nExiting " << __func__ << " in " << __FILE__ << std::endl;

    std::cerr << "lj_long_range_ internal:\n";
    for (size_t i = 0; i < lj_long_range_.size(); i++) {
        std::cerr << lj_long_range_[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "xyz internal:\n";
    for (size_t i = 0; i < xyz_.size(); i++) {
        std::cerr << xyz_[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "is_local_atom internal:\n";
    for (size_t i = 0; i < islocal_atom_.size(); i++) {
        std::cerr << islocal_atom_[i] << " , ";
    }
    std::cerr << std::endl;
#endif
}

void LennardJones::SetJsonLennardJones(nlohmann::json repdisp_j) { repdisp_j_ = repdisp_j; }
void LennardJones::SetJsonMonomers(nlohmann::json mon_j) { mon_j_ = mon_j; }

nlohmann::json LennardJones::GetJsonLennardJones() { return repdisp_j_; }
nlohmann::json LennardJones::GetJsonMonomers() { return mon_j_; }

void LennardJones::SetMPI(MPI_Comm world, size_t proc_grid_x, size_t proc_grid_y, size_t proc_grid_z) {
    mpi_initialized_ = true;
    world_ = world;
    proc_grid_x_ = proc_grid_x;
    proc_grid_y_ = proc_grid_y;
    proc_grid_z_ = proc_grid_z;
}

void LennardJones::SetNewParameters(const std::vector<double> &xyz,
                                    std::vector<std::pair<std::string, std::string> > use_lj, bool do_grads = true,
                                    const double cutoff = 100.0, const std::vector<double> &box = {}) {
#ifdef DEBUG
    std::cerr << std::scientific << std::setprecision(10);
    std::cerr << "\nEntering " << __func__ << " in " << __FILE__ << std::endl;

    std::cerr << "Sys Xyz:\n";
    for (size_t i = 0; i < xyz.size(); i++) {
        std::cerr << xyz[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "box:\n";
    for (size_t i = 0; i < box.size(); i++) {
        std::cerr << box[i] << " , ";
    }
    std::cerr << std::endl;

    std::cerr << "doGrads = " << do_grads << std::endl;
    std::cerr << "cutoff = " << cutoff << std::endl;
#endif

    sys_xyz_ = xyz;
    use_lj_ = use_lj;
    box_ = box;
    box_inverse_ = box.size() ? InvertUnitCell(box) : std::vector<double>{};
    box_ABCabc_ = box.size() ? BoxVecToBoxABCabc(box) : std::vector<double>{};
    use_pbc_ = box.size();
    do_grads_ = do_grads;
    do_field_ = false;
    cutoff_ = cutoff;
    std::fill(grad_.begin(), grad_.end(), 0.0);
    std::fill(phi_.begin(), phi_.end(), 0.0);
    std::fill(virial_.begin(), virial_.end(), 0.0);

    box_PMElocal_ = {};

    ReorderData();

#ifdef DEBUG
    std::cerr << std::scientific << std::setprecision(10);
    std::cerr << "\nExiting " << __func__ << " in " << __FILE__ << std::endl;

    std::cerr << "xyz internal:\n";
    for (size_t i = 0; i < xyz_.size(); i++) {
        std::cerr << xyz_[i] << " , ";
    }
    std::cerr << std::endl;
#endif
}

void LennardJones::SetBoxPMElocal(std::vector<double> box) {
    box_PMElocal_ = box;
    box_ABCabc_PMElocal_ = box.size() ? BoxVecToBoxABCabc(box) : std::vector<double>{};
}

void LennardJones::ReorderData() {
    // Organize xyz so we have
    // x1_1 x1_2 ... y1_1 y1_2... z1_1 z1_2 ... x2_1 x2_2 ...
    // where xN_M is read as coordinate x of site N of monomer M
    // for the first monomer type. Then follows the second, and so on.
    // As an example, for a water dimer (OHHM), the system xyz would be
    // sys_xyz = {Ox, Oy, Oz, Hx, Hy, Hz, Hx, Hy, ...}
    // And after reordering,
    // xyz = {Ox, Ox, Oy, Oy, Oz, Oz, Hx, Hx, Hy, Hy, Hz, Hz, Hx, Hx, ... ...}

    size_t fi_mon = 0;
    size_t fi_crd = 0;
    size_t fi_sites = 0;
    for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
        size_t ns = num_atoms_[fi_mon];
        size_t nmon = mon_type_count_[mt].second;
        size_t nmon2 = nmon * 2;
        for (size_t m = 0; m < nmon; m++) {
            size_t mns = m * ns;
            size_t mns3 = mns * 3;
            for (size_t i = 0; i < ns; i++) {
                size_t inmon = i * nmon;
                size_t inmon3 = 3 * inmon;
                xyz_[inmon3 + m + fi_crd] = sys_xyz_[fi_crd + mns3 + 3 * i];
                xyz_[inmon3 + m + fi_crd + nmon] = sys_xyz_[fi_crd + mns3 + 3 * i + 1];
                xyz_[inmon3 + m + fi_crd + nmon2] = sys_xyz_[fi_crd + mns3 + 3 * i + 2];
                lj_long_range_[fi_sites + m + inmon] = sys_lj_long_range_[fi_sites + mns + i];
                islocal_atom_[fi_sites + m + inmon] = islocal_[fi_mon + m];
            }
        }
        fi_mon += nmon;
        fi_sites += nmon * ns;
        fi_crd += nmon * ns * 3;
    }
}

double LennardJones::GetLennardJones(std::vector<double> &grad, std::vector<double> *virial, bool use_ghost) {
#ifdef DEBUG
    std::cerr << std::scientific << std::setprecision(10);
    std::cerr << "\nEntering " << __func__ << " in " << __FILE__ << std::endl;

    std::cerr << "grad:\n";
    for (size_t i = 0; i < grad.size(); i++) {
        std::cerr << grad[i] << " , ";
    }
    std::cerr << std::endl;

    if (virial != 0) {
        std::cerr << "virial:\n";
        for (size_t i = 0; i < (*virial).size(); i++) {
            std::cerr << (*virial)[i] << " , ";
        }
        std::cerr << std::endl;
    }

    std::cerr << "use_ghost = " << use_ghost << std::endl;
#endif

    calc_virial_ = false;

    if (virial != 0) {
        calc_virial_ = true;
    }

    std::fill(virial_.begin(), virial_.end(), 0.0);
    CalculateLennardJones(use_ghost);

    size_t fi_mon = 0;
    size_t fi_crd = 0;
    size_t fi_sites = 0;

    if (calc_virial_) {
        (*virial)[0] += virial_[0];
        (*virial)[1] += virial_[1];
        (*virial)[2] += virial_[2];
        (*virial)[3] += virial_[3];
        (*virial)[4] += virial_[4];
        (*virial)[5] += virial_[5];
        (*virial)[6] += virial_[6];
        (*virial)[7] += virial_[7];
        (*virial)[8] += virial_[8];
    }

    for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
        size_t ns = num_atoms_[fi_mon];
        size_t nmon = mon_type_count_[mt].second;
        size_t nmon2 = nmon * 2;
        for (size_t m = 0; m < nmon; m++) {
            size_t mns = m * ns;
            size_t mns3 = mns * 3;
            for (size_t i = 0; i < ns; i++) {
                size_t inmon = i * nmon;
                size_t inmon3 = 3 * inmon;

                sys_phi_[fi_sites + mns + i] = phi_[fi_sites + m + inmon];

                grad[fi_crd + mns3 + 3 * i] += grad_[inmon3 + m + fi_crd];
                grad[fi_crd + mns3 + 3 * i + 1] += grad_[inmon3 + m + fi_crd + nmon];
                grad[fi_crd + mns3 + 3 * i + 2] += grad_[inmon3 + m + fi_crd + nmon2];
            }
        }
        fi_mon += nmon;
        fi_sites += nmon * ns;
        fi_crd += nmon * ns * 3;
    }

#ifdef DEBUG
    std::cerr << std::scientific << std::setprecision(10);
    std::cerr << "\nExiting " << __func__ << " in " << __FILE__ << std::endl;

    std::cerr << "grad:\n";
    for (size_t i = 0; i < grad.size(); i++) {
        std::cerr << grad[i] << " , ";
    }
    std::cerr << std::endl;

    if (virial != 0) {
        std::cerr << "virial:\n";
        for (size_t i = 0; i < (*virial).size(); i++) {
            std::cerr << (*virial)[i] << " , ";
        }
        std::cerr << std::endl;
    }

    std::cerr << "LennardJones energy = " << lj_energy_ << std::endl;
#endif

    return lj_energy_;
}

double LennardJones::GetLennardJonesPME(std::vector<double> &grad, std::vector<double> *virial, bool use_ghost) {
    calc_virial_ = false;

    if (virial != 0) {
        calc_virial_ = true;
    }

    std::fill(virial_.begin(), virial_.end(), 0.0);
    CalculateLennardJonesPME(use_ghost);

    size_t fi_mon = 0;
    size_t fi_crd = 0;
    size_t fi_sites = 0;

    if (calc_virial_) {
        (*virial)[0] += virial_[0];
        (*virial)[1] += virial_[1];
        (*virial)[2] += virial_[2];
        (*virial)[3] += virial_[3];
        (*virial)[4] += virial_[4];
        (*virial)[5] += virial_[5];
        (*virial)[6] += virial_[6];
        (*virial)[7] += virial_[7];
        (*virial)[8] += virial_[8];
    }

    for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
        size_t ns = num_atoms_[fi_mon];
        size_t nmon = mon_type_count_[mt].second;
        size_t nmon2 = nmon * 2;
        for (size_t m = 0; m < nmon; m++) {
            size_t mns = m * ns;
            size_t mns3 = mns * 3;
            for (size_t i = 0; i < ns; i++) {
                size_t inmon = i * nmon;
                size_t inmon3 = 3 * inmon;

                sys_phi_[fi_sites + mns + i] = phi_[fi_sites + m + inmon];

                grad[fi_crd + mns3 + 3 * i] += grad_[inmon3 + m + fi_crd];
                grad[fi_crd + mns3 + 3 * i + 1] += grad_[inmon3 + m + fi_crd + nmon];
                grad[fi_crd + mns3 + 3 * i + 2] += grad_[inmon3 + m + fi_crd + nmon2];
            }
        }
        fi_mon += nmon;
        fi_sites += nmon * ns;
        fi_crd += nmon * ns * 3;
    }

    return lj_energy_;
}

double LennardJones::GetLennardJonesPMElocal(std::vector<double> &grad, std::vector<double> *virial, bool use_ghost) {
    calc_virial_ = false;

    if (virial != 0) {
        calc_virial_ = true;
    }

    std::fill(virial_.begin(), virial_.end(), 0.0);
    CalculateLennardJonesPMElocal(use_ghost);

    if (calc_virial_) {
        (*virial)[0] += virial_[0];
        (*virial)[1] += virial_[1];
        (*virial)[2] += virial_[2];
        (*virial)[3] += virial_[3];
        (*virial)[4] += virial_[4];
        (*virial)[5] += virial_[5];
        (*virial)[6] += virial_[6];
        (*virial)[7] += virial_[7];
        (*virial)[8] += virial_[8];
    }

    if (natoms_ > 0) {
        size_t fi_mon = 0;
        size_t fi_crd = 0;
        size_t fi_sites = 0;

        for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
            size_t ns = num_atoms_[fi_mon];
            size_t nmon = mon_type_count_[mt].second;
            size_t nmon2 = nmon * 2;
            for (size_t m = 0; m < nmon; m++) {
                size_t mns = m * ns;
                size_t mns3 = mns * 3;
                for (size_t i = 0; i < ns; i++) {
                    size_t inmon = i * nmon;
                    size_t inmon3 = 3 * inmon;

                    sys_phi_[fi_sites + mns + i] = phi_[fi_sites + m + inmon];

                    grad[fi_crd + mns3 + 3 * i] += grad_[inmon3 + m + fi_crd];
                    grad[fi_crd + mns3 + 3 * i + 1] += grad_[inmon3 + m + fi_crd + nmon];
                    grad[fi_crd + mns3 + 3 * i + 2] += grad_[inmon3 + m + fi_crd + nmon2];
                }
            }
            fi_mon += nmon;
            fi_sites += nmon * ns;
            fi_crd += nmon * ns * 3;
        }
    }

    return lj_energy_;
}

void LennardJones::CalculateLennardJones(bool use_ghost) {
    lj_energy_ = 0.0;
    std::fill(phi_.begin(), phi_.end(), 0.0);
    // Max number of monomers
    size_t maxnmon = mon_type_count_.size() == 0 ? 0 : mon_type_count_.back().second;
    // Parallelization
    size_t nthreads = 1;
#ifdef _OPENMP
#pragma omp parallel  // omp_get_num_threads() needs to be inside
                      // parallel region to get number of threads
    {
        if (omp_get_thread_num() == 0) nthreads = omp_get_num_threads();
    }
#endif

    // This part looks at sites inside the same monomer
    // Reset first indexes
    size_t fi_mon = 0;
    size_t fi_crd = 0;
    size_t fi_sites = 0;

    // Excluded sets
    excluded_set_type exc12;
    excluded_set_type exc13;
    excluded_set_type exc14;

    // Loop over each monomer type
    for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
        size_t ns = num_atoms_[fi_mon];
        size_t nmon = mon_type_count_[mt].second;
        size_t nmon2 = 2 * nmon;
        double dummy_eps, dummy_sigma;
        bool do_lj = GetLjParams(mon_id_[fi_mon], mon_id_[fi_mon], 0, 0, dummy_eps, dummy_sigma, use_lj_, repdisp_j_);

        std::vector<double> xyz_mt(xyz_.begin() + fi_crd, xyz_.begin() + fi_crd + nmon * ns * 3);

        // Obtain excluded pairs for monomer type mt
        systools::GetExcluded(mon_id_[fi_mon], mon_j_, exc12, exc13, exc14);

        // For parallel region
        std::vector<std::vector<double> > phi_pool;
        std::vector<std::vector<double> > grad_pool;
        std::vector<double> energy_pool(nthreads, 0.0);
        std::vector<std::vector<double> > virial_pool;

        for (size_t i = 0; i < nthreads; i++) {
            phi_pool.push_back(std::vector<double>(nmon * ns, 0.0));
            grad_pool.push_back(std::vector<double>(nmon * ns * 3, 0.0));
            virial_pool.push_back(std::vector<double>(9, 0.0));
        }

        std::vector<double> sigmas(ns*ns, 0.0);
        std::vector<double> epss(ns*ns, 0.0);

        for (size_t i = 0; i < ns - 1; i++) {
            for (size_t j = i + 1; j < ns; j++) {
                GetLjParams(mon_id_[fi_mon], mon_id_[fi_mon], i, j, epss[i*ns + j], sigmas[i*ns + j], use_lj_, repdisp_j_);
            }
        }
        
#ifdef _OPENMP
#pragma omp parallel for schedule(dynamic)
#endif
        for (size_t m = 0; m < nmon; m++) {
            int rank = 0;
#ifdef _OPENMP
            rank = omp_get_thread_num();
#endif
            // Loop over each pair of sites
            for (size_t i = 0; i < ns - 1; i++) {
                size_t inmon = i * nmon;
                size_t inmon3 = inmon * 3;
                for (size_t j = i + 1; j < ns; j++) {
                    // Continue only if i and j are not bonded
                    bool is12 = systools::IsExcluded(exc12, i, j);
                    bool is13 = systools::IsExcluded(exc13, i, j);
                    bool is14 = systools::IsExcluded(exc14, i, j);
                    double lj_scale_factor = (is12 || is13 || is14 || !do_lj) ? 0 : 1;
                    double eps = epss[i*ns + j];
                    double sigma = sigmas[i*ns + j];
                    double ljchgi = lj_long_range_[fi_sites + i * nmon];
                    double ljchgj = lj_long_range_[fi_sites + j * nmon];

                    bool include_monomer = false;
                    if (!use_ghost) include_monomer = true;
                    if (use_ghost && islocal_[fi_mon + m]) include_monomer = true;

                    if (include_monomer) {
                        std::vector<double> p1(3, 0.0);
                        std::vector<double> g1(3, 0.0);
                        double phi_i = 0.0;
                        p1[0] = xyz_mt[inmon3 + m];
                        p1[1] = xyz_mt[inmon3 + nmon + m];
                        p1[2] = xyz_mt[inmon3 + nmon2 + m];
                        energy_pool[rank] +=
                            lj(eps, sigma, ljchgi, ljchgj, p1, xyz_mt, g1, grad_pool[rank], phi_i, phi_pool[rank], nmon,
                            nmon, m, m + 1, i, j, lj_scale_factor, do_grads_, do_field_, cutoff_, ewald_alpha_, box_,
                            box_inverse_, use_ghost, islocal_, fi_mon + m, fi_mon, &virial_pool[rank]);
                        grad_pool[rank][inmon3 + m] += g1[0];
                        grad_pool[rank][inmon3 + nmon + m] += g1[1];
                        grad_pool[rank][inmon3 + nmon2 + m] += g1[2];
                        phi_pool[rank][inmon + m] += phi_i;
                    }
                }
            }
        }

        // Compress data in phi and grad and virial
        for (size_t rank = 0; rank < nthreads; rank++) {
            size_t kend = phi_pool[rank].size();
            for (size_t k = 0; k < kend; k++) {
                phi_[fi_sites + k] += phi_pool[rank][k];
            }
            kend = grad_pool[rank].size();
            for (size_t k = 0; k < kend; k++) {
                grad_[fi_crd + k] += grad_pool[rank][k];
            }
            for (size_t k = 0; k < 9; k++) {
                virial_[k] += virial_pool[rank][k];
            }
            lj_energy_ += energy_pool[rank];
        }

        fi_mon += nmon;
        fi_sites += nmon * ns;
        fi_crd += nmon * ns * 3;
    }

    bool use_pbc = box_.size();
        
    int nsite_types = 0;
    size_t fi_mon1 = 0;
    size_t total_atoms = 0;
    for (size_t mt1 = 0; mt1 < mon_type_count_.size(); mt1++) {
        nsite_types += num_atoms_[fi_mon1];
        total_atoms += mon_type_count_[mt1].second * num_atoms_[fi_mon1];
        fi_mon1 += mon_type_count_[mt1].second;
    }
        
    // Sites corresponding to different monomers
    // Declaring first indexes
    size_t fi_sites1 = 0;
    size_t fi_mon2 = 0;
    size_t fi_sites2 = 0;
    size_t fi_crd1 = 0;
    size_t fi_crd2 = 0;
    size_t fi_sitetypes = 0;
    size_t fi_sitetypes2 = 0;
    
    vector<vector<size_t>> neighbor_list(natoms_  * nsite_types);

    if (total_atoms > algorithm_configuration_parameters::KDTREE_CUTOFF) {

        //Rearranging the coordinates (into xyzxyz order) and moving the points into the box (if pbc)
        std::vector<double> xyz_rearranged(xyz_.size());
        std::vector<size_t> point_monomer_type_indices(xyz_.size()/3);
        std::vector<size_t> point_site_indices(xyz_.size()/3);
        std::vector<size_t> point_monomer_indices(xyz_.size()/3);
        std::vector<size_t> point_fi_mon2(xyz_.size()/3);
        fi_mon = 0;
        fi_crd = 0;
        fi_sitetypes = 0;
        size_t site_count = xyz_rearranged.size()/3;
        //fi_mon has the index of the first monomer of this monomer type
        //for each monomer type
        for(size_t mt = 0; mt<mon_type_count_.size(); mt++){
            //for each site of that monomer type
            //nmon = number of monomers of that type
            size_t nmon = mon_type_count_[mt].second;
            size_t ns = num_atoms_[fi_mon];
            for(size_t s = 0; s < ns; s++){
                #pragma omp parallel for schedule(dynamic)
                for(size_t i = 0; i<nmon; ++i){
                    if(use_pbc){
                        double x = box_inverse_[0]*xyz_[fi_crd+i] + box_inverse_[3]*xyz_[fi_crd+i+nmon] + box_inverse_[6]*xyz_[fi_crd+i+2*nmon],
                            y = box_inverse_[1]*xyz_[fi_crd+i] + box_inverse_[4]*xyz_[fi_crd+i+nmon] + box_inverse_[7]*xyz_[fi_crd+i+2*nmon],
                            z = box_inverse_[2]*xyz_[fi_crd+i] + box_inverse_[5]*xyz_[fi_crd+i+nmon] + box_inverse_[8]*xyz_[fi_crd+i+2*nmon];
                        
                        x -= std::floor(x + 0.5);
                        y -= std::floor(y + 0.5);
                        z -= std::floor(z + 0.5);

                        xyz_rearranged[fi_crd+3*i] = box_[0]*x + box_[3]*y + box_[6]*z;
                        xyz_rearranged[fi_crd+3*i+1] = box_[1]*x + box_[4]*y + box_[7]*z;
                        xyz_rearranged[fi_crd+3*i+2] = box_[2]*x + box_[5]*y + box_[8]*z;
                    }
                    else{
                        xyz_rearranged[fi_crd+3*i] = xyz_[fi_crd+i];
                        xyz_rearranged[fi_crd+3*i+1] = xyz_[fi_crd+i+nmon];
                        xyz_rearranged[fi_crd+3*i+2] = xyz_[fi_crd+i+nmon*2];
                    }
                    point_monomer_type_indices[fi_crd/3+i] = mt;
                    point_site_indices[fi_crd/3+i] = s;
                    point_monomer_indices[fi_crd/3+i] = i;
                    point_fi_mon2[fi_crd/3+i] = fi_mon;
                }
                fi_crd += nmon*3;
            }
            fi_mon += nmon;
        }

        typedef nanoflann::KDTreeSingleIndexAdaptor<nanoflann::L2_Simple_Adaptor<double, kdtutils::PointCloud<double>>,
                                                        kdtutils::PointCloud<double>, 3 /* dim */>
            my_kd_tree_t;

        std::vector<size_t> tree_indices(0);
        kdtutils::PointCloud<double> cloud = kdtutils::XyzToCloudCutoff(xyz_rearranged, cutoff_, use_pbc, box_, box_inverse_, tree_indices);
        my_kd_tree_t tree(3 /*dim*/, cloud, nanoflann::KDTreeSingleIndexAdaptorParams(20 /* max leaf */));
        tree.buildIndex();

        fi_mon1 = 0;
        fi_crd1 = 0;
        fi_sites1 = 0;
        fi_mon2 = 0;
        fi_sitetypes2 = 0;

        vector<std::unordered_set<size_t, std::hash<size_t>, std::equal_to<size_t>, allocator<size_t>>> neighbor_list_lookup(natoms_  * nsite_types);

        for(size_t mt1 = 0; mt1 < mon_type_count_.size(); mt1++){

            size_t ns1 = num_atoms_[fi_mon1];
            size_t nmon1 = mon_type_count_[mt1].second;

            #pragma omp parallel for schedule(dynamic)
            for (size_t m1 = 0; m1 < nmon1; m1++) {
                for (size_t i = 0; i < ns1; i++) {

                    vector<size_t> point_fi_sitetypes2(mon_type_count_.size() - mt1);


                    size_t fi_mon2_iter = fi_mon1;
                    size_t fi_sitetypes_iter = 0;
                    for (size_t mt2 = mt1; mt2 < mon_type_count_.size(); mt2++) {
                        size_t ns2 = num_atoms_[fi_mon2_iter];
                        size_t nmon2 = mon_type_count_[mt2].second;
                        point_fi_sitetypes2[mt2 - mt1] = fi_sitetypes_iter;
                        fi_sitetypes_iter += ns2;
                        fi_mon2_iter += nmon2;
                    }

                    size_t inmon13 = 3 * nmon1 * i;
                    
                    bool point1_local = islocal_[fi_mon1+m1]==1;

                    double point[3];
                    point[0] = xyz_rearranged[fi_crd1+inmon13+m1*3];
                    point[1] = xyz_rearranged[fi_crd1+inmon13+m1*3+1];
                    point[2] = xyz_rearranged[fi_crd1+inmon13+m1*3+2];

                    std::vector<std::pair<size_t, double>> site2_indices;
                    nanoflann::SearchParams params(32, 0, false);

                    const size_t nMatches = tree.radiusSearch(point, cutoff_*cutoff_, site2_indices, params);
                    
                    for(size_t s = 0; s<nMatches; ++s){
                        //getting the actual index (not periodic index) of the monomer
                        // size_t idx = site2_indices[s].first % nmon2;
                        size_t idx = tree_indices[site2_indices[s].first];
                        size_t mt2 = point_monomer_type_indices[idx];
                        size_t j = point_site_indices[idx];
                        size_t m2 = point_monomer_indices[idx];

                        if (mt2 >= mt1) { 
                            size_t fi_selected_mon2 = point_fi_mon2[idx];
                            size_t fi_selected_sitetypes2 = point_fi_sitetypes2[mt2 - mt1];
                            
                            size_t m2init = mt1 == mt2 ? m1 + 1 : 0;

                            if((!use_ghost || (use_ghost && (point1_local || islocal_[fi_selected_mon2+m2]))) && m2 >= m2init){
                                if(neighbor_list_lookup[(fi_sites1 + m1*ns1 + i)*nsite_types + fi_selected_sitetypes2 + j].find(m2) == neighbor_list_lookup[(fi_sites1 + m1*ns1 + i)*nsite_types + fi_selected_sitetypes2 + j].end()) {
                                    neighbor_list[(fi_sites1 + m1*ns1 + i)*nsite_types + fi_selected_sitetypes2 + j].push_back(m2);
                                    neighbor_list_lookup[(fi_sites1 + m1*ns1 + i)*nsite_types + fi_selected_sitetypes2 + j].insert(m2);
                                }
                            }
                        }
                    }
                            
                }

            }
            fi_mon1 += nmon1;
            fi_crd1 += nmon1 * ns1 * 3;
            fi_sites1 += nmon1 * ns1;
        }
        
    }

    fi_mon1 = 0;
    fi_crd1 = 0;
    fi_sites1 = 0;
    fi_mon2 = 0;
    fi_sitetypes2 = 0;

    // Loop over all monomer types
    for (size_t mt1 = 0; mt1 < mon_type_count_.size(); mt1++) {
        size_t ns1 = num_atoms_[fi_mon1];
        size_t nmon1 = mon_type_count_[mt1].second;
        size_t nmon12 = nmon1 * 2;
        fi_mon2 = fi_mon1;
        fi_sites2 = fi_sites1;
        fi_crd2 = fi_crd1;

        fi_sitetypes2 = 0;

        // For each monomer type mt1, loop over all the other monomer types
        // mt2 >= mt1 to avoid double counting
        for (size_t mt2 = mt1; mt2 < mon_type_count_.size(); mt2++) {
            size_t ns2 = num_atoms_[fi_mon2];
            size_t nmon2 = mon_type_count_[mt2].second;

            double dummy_eps, dummy_sigma;
            bool do_lj =
                GetLjParams(mon_id_[fi_mon1], mon_id_[fi_mon2], 0, 0, dummy_eps, dummy_sigma, use_lj_, repdisp_j_);
            double* xyz_mt2 = xyz_.data() + fi_crd2;
            double lj_scale_factor = do_lj ? 1.0 : 0.0;
            // Check if monomer types 1 and 2 are the same
            // If so, same monomer won't be done, since it has been done in
            // previous loop.
            bool same = (mt1 == mt2);

            // For parallel region
            std::vector<std::vector<double>> phi1_pool(nthreads);
            std::vector<std::vector<double>> phi2_pool(nthreads);
            std::vector<std::vector<double>> grad1_pool(nthreads);
            std::vector<std::vector<double>> grad2_pool(nthreads);
            std::vector<double> energy_pool(nthreads, 0.0);
            std::vector<std::vector<double>> virial_pool(nthreads);
            std::vector<std::shared_ptr<std::vector<size_t>>> bool_mon2_indices_pool(nthreads);
            std::vector<std::shared_ptr<elec::ElectricFieldHolder>> field_pool(nthreads);

            #pragma omp parallel for schedule(static, 1)
            for (size_t i = 0; i < nthreads; i++) {
                phi1_pool[i] = std::vector<double>(nmon1 * ns1, 0.0);
                phi2_pool[i] = std::vector<double>(nmon2 * ns2, 0.0);
                grad1_pool[i] = std::vector<double>(nmon1 * ns1 * 3, 0.0);
                grad2_pool[i] = std::vector<double>(nmon2 * ns2 * 3, 0.0);
                virial_pool[i] = std::vector<double>(9, 0.0);
                bool_mon2_indices_pool[i] = std::make_shared<std::vector<size_t>>(nmon2);
                field_pool[i] = std::make_shared<elec::ElectricFieldHolder>(maxnmon);
            }
#ifdef _OPENMP
#pragma omp parallel for schedule(dynamic)
#endif
            for (size_t m1 = 0; m1 < nmon1; m1++) {
                int rank = 0;
#ifdef _OPENMP
                rank = omp_get_thread_num();
#endif
                size_t m2init = same ? m1 + 1 : 0;

                for (size_t i = 0; i < ns1; i++) {
                    size_t inmon1 = i * nmon1;
                    size_t inmon13 = inmon1 * 3;

                    double ljchgi = lj_long_range_[fi_sites1 + i * nmon1];
                    std::vector<double> xyz_sitei(3);
                    std::vector<double> g1(3, 0.0);
                    double phi_i = 0.0;
                    xyz_sitei[0] = xyz_[fi_crd1 + inmon13 + m1];
                    xyz_sitei[1] = xyz_[fi_crd1 + inmon13 + nmon1 + m1];
                    xyz_sitei[2] = xyz_[fi_crd1 + inmon13 + 2 * nmon1 + m1];

                    for (size_t j = 0; j < ns2; j++) {
                        size_t jnmon2 = j * nmon2;
                        size_t jnmon23 = jnmon2 * 3;
                        double ljchgj = lj_long_range_[fi_sites2 + j * nmon2];
                        double eps, sigma;
                        GetLjParams(mon_id_[fi_mon1], mon_id_[fi_mon2], i, j, eps, sigma, use_lj_, repdisp_j_);

                        vector<size_t> good_mon2_indices;
                        
                        if (do_field_) {
                            for(size_t idx = m2init; idx < nmon2; ++idx){
                                good_mon2_indices.push_back(idx);
                            }
                        } else if (total_atoms > algorithm_configuration_parameters::KDTREE_CUTOFF) {
                            good_mon2_indices = neighbor_list[(fi_sites1 + m1*ns1 + i)*nsite_types + fi_sitetypes2 + j];
                        } else {
                            std::vector<size_t>& bool_mon2_indices = *bool_mon2_indices_pool[rank];
                            std::fill(bool_mon2_indices.begin(), bool_mon2_indices.end(), 0.0);
                            field_pool[rank]->FindMonomersWithinCutoff(bool_mon2_indices.data(), xyz_.data() + fi_crd1, xyz_.data() + fi_crd2, m2init, 
                                                                        nmon1, nmon2, use_pbc, box_, box_inverse_, cutoff_, i, j,
                                                                        m1, use_ghost, islocal_, fi_mon1 + m1, fi_mon2);

                            int num_good_mon2 = 0;
                            for (int ind = 0; ind < nmon2; ind++) {
                                if (bool_mon2_indices[ind] == 1) {
                                    num_good_mon2++;
                                }
                            }

                            good_mon2_indices.resize(num_good_mon2);
                            int current_good_mon2_index = 0;
                            // monomer 2s within the cutoff are stored in good_mon2_indices
                            for (int ind = 0; ind < nmon2; ind++) {
                                if (bool_mon2_indices[ind] == 1) {
                                    good_mon2_indices[current_good_mon2_index] = ind;
                                    current_good_mon2_index++;
                                }
                            }
                        }
                        


                        std::size_t reordered_mon2_size = good_mon2_indices.size();

                        std::vector<double> reordered_xyz2(3*reordered_mon2_size);
                        std::vector<std::size_t> reordered_islocal(reordered_mon2_size + 1);
                        std::vector<double> reordered_grad2(3*reordered_mon2_size, 0.0);
                        std::vector<double> reordered_phi2(reordered_mon2_size, 0.0);

                        reordered_islocal[0] = islocal_[fi_mon1 + m1];

                        for (int new_mon2_index = 0; new_mon2_index < reordered_mon2_size; new_mon2_index++){
                            int old_mon2_index = good_mon2_indices[new_mon2_index];
                            reordered_xyz2[new_mon2_index] = xyz_mt2[old_mon2_index + nmon2 * j * 3];
                            reordered_xyz2[new_mon2_index + reordered_mon2_size] = xyz_mt2[old_mon2_index + nmon2 + nmon2 * j * 3];
                            reordered_xyz2[new_mon2_index + 2*reordered_mon2_size] = xyz_mt2[old_mon2_index + 2*nmon2 + nmon2 * j * 3];
                            reordered_islocal[new_mon2_index + 1] = islocal_[fi_mon2 + old_mon2_index];
                        }

                        energy_pool[rank] += lj(eps, sigma, ljchgi, ljchgj, xyz_sitei, reordered_xyz2, g1, reordered_grad2,
                                                phi_i, reordered_phi2, nmon1, reordered_mon2_size, 0, reordered_mon2_size, i, 0,
                                                lj_scale_factor, do_grads_, do_field_, cutoff_, ewald_alpha_, box_, box_inverse_,
                                                use_ghost, reordered_islocal, 0, 1, &virial_pool[rank]);

                        // energy_pool[rank] += lj(eps, sigma, ljchgi, ljchgj, xyz_sitei, xyz_mt2, g1, grad2_pool[rank],
                        //                         phi_i, phi2_pool[rank], nmon1, nmon2, m2init, nmon2, i, j,
                        //                         lj_scale_factor, do_grads_, cutoff_, ewald_alpha_, box_, box_inverse_,
                        //                         use_ghost, islocal_, fi_mon1 + m1, fi_mon2, &virial_pool[rank]);

                        for (int new_mon2_index = 0; new_mon2_index < reordered_mon2_size; new_mon2_index++ ){
                            int old_mon2_index = good_mon2_indices[new_mon2_index];
                            phi2_pool[rank][nmon2 * j + old_mon2_index] += reordered_phi2[new_mon2_index];
                            grad2_pool[rank][nmon2 * j * 3 + old_mon2_index] += reordered_grad2[new_mon2_index];
                            grad2_pool[rank][nmon2 * j * 3 + nmon2 + old_mon2_index] += reordered_grad2[reordered_mon2_size + new_mon2_index];
                            grad2_pool[rank][nmon2 * j * 3 + 2*nmon2 + old_mon2_index] += reordered_grad2[2*reordered_mon2_size + new_mon2_index];
                        }
                    }
                    grad1_pool[rank][inmon13 + m1] += g1[0];
                    grad1_pool[rank][inmon13 + nmon1 + m1] += g1[1];
                    grad1_pool[rank][inmon13 + nmon12 + m1] += g1[2];
                    phi1_pool[rank][inmon1 + m1] += phi_i;
                }
            }

            // Compress data in Efq and phi
            for (size_t rank = 0; rank < nthreads; rank++) {
                size_t kend1 = grad1_pool[rank].size();
                size_t kend2 = grad2_pool[rank].size();
                for (size_t k = 0; k < kend1; k++) {
                    grad_[fi_crd1 + k] += grad1_pool[rank][k];
                }
                for (size_t k = 0; k < kend2; k++) {
                    grad_[fi_crd2 + k] += grad2_pool[rank][k];
                }
                kend1 = phi1_pool[rank].size();
                kend2 = phi2_pool[rank].size();
                for (size_t k = 0; k < kend1; k++) {
                    phi_[fi_sites1 + k] += phi1_pool[rank][k];
                }
                for (size_t k = 0; k < kend2; k++) {
                    phi_[fi_sites2 + k] += phi2_pool[rank][k];
                }
                for (size_t k = 0; k < 9; k++) {
                    virial_[k] += virial_pool[rank][k];
                }
                lj_energy_ += energy_pool[rank];
            }

            // Update first indexes
            fi_mon2 += nmon2;
            fi_sites2 += nmon2 * ns2;
            fi_crd2 += nmon2 * ns2 * 3;
            
            fi_sitetypes2 += ns2;
        }
        // Update first indexes
        fi_mon1 += nmon1;
        fi_sites1 += nmon1 * ns1;
        fi_crd1 += nmon1 * ns1 * 3;
    }

    if (ewald_alpha_ > 0 && use_pbc_) {
        helpme::PMEInstance<double> pme_solver_;
        if (user_fft_grid_.size()) pme_solver_.SetFFTDimension(user_fft_grid_);
        // Compute the reciprocal space terms, using PME
        double A = box_ABCabc_[0];
        double B = box_ABCabc_[1];
        double C = box_ABCabc_[2];
        double alpha = box_ABCabc_[3];
        double beta = box_ABCabc_[4];
        double gamma = box_ABCabc_[5];

        int grid_A = pme_grid_density_ * A;
        int grid_B = pme_grid_density_ * B;
        int grid_C = pme_grid_density_ * C;
        pme_solver_.setup(6, ewald_alpha_, pme_spline_order_, grid_A, grid_B, grid_C, -1, 0);
        pme_solver_.setLatticeVectors(A, B, C, alpha, beta, gamma, PMEInstanceD::LatticeType::XAligned);
        // N.B. these do not make copies; they just wrap the memory with some metadata
        auto coords = helpme::Matrix<double>(sys_xyz_.data(), natoms_, 3);
        auto params = helpme::Matrix<double>(sys_lj_long_range_.data(), natoms_, 1);
        auto forces = helpme::Matrix<double>(sys_grad_.data(), natoms_, 3);
        std::vector<double> dummy_6vec(6, 0.0);
        auto rec_virial = helpme::Matrix<double>(dummy_6vec.data(), 6, 1);
        std::fill(sys_grad_.begin(), sys_grad_.end(), 0);
        double rec_energy = pme_solver_.computeEFVRec(0, params, coords, forces, rec_virial);

        // get virial
        if (calc_virial_) {
            virial_[0] += *rec_virial[0];
            virial_[1] += *rec_virial[1];
            virial_[2] += *rec_virial[3];
            virial_[4] += *rec_virial[2];
            virial_[5] += *rec_virial[4];
            virial_[8] += *rec_virial[5];

            virial_[3] = virial_[1];
            virial_[6] = virial_[2];
            virial_[7] = virial_[5];
        }

        // Resort forces from system order
        fi_mon = 0;
        fi_sites = 0;
        for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
            size_t ns = num_atoms_[fi_mon];
            size_t nmon = mon_type_count_[mt].second;
            for (size_t m = 0; m < nmon; m++) {
                size_t mns = m * ns;
                for (size_t i = 0; i < ns; i++) {
                    size_t inmon = i * nmon;
                    const double *result_ptr = forces[fi_sites + mns + i];
                    grad_[3 * fi_sites + 3 * inmon + 0 * nmon + m] -= result_ptr[0];
                    grad_[3 * fi_sites + 3 * inmon + 1 * nmon + m] -= result_ptr[1];
                    grad_[3 * fi_sites + 3 * inmon + 2 * nmon + m] -= result_ptr[2];
                }
            }
            fi_mon += nmon;
            fi_sites += nmon * ns;
        }
        // The Ewald self energy
        double prefac = std::pow(ewald_alpha_, 6) / 12.0;
        double self_energy = 0;
        for (const auto &lji : sys_lj_long_range_) {
            self_energy += lji * lji * prefac;
        }
        lj_energy_ += rec_energy + self_energy;
    }
}

void LennardJones::CalculateLennardJonesPME(bool use_ghost) {
    lj_energy_ = 0.0;
    std::fill(phi_.begin(), phi_.end(), 0.0);
    // Parallelization
    size_t nthreads = 1;
#ifdef _OPENMP
#pragma omp parallel  // omp_get_num_threads() needs to be inside
                      // parallel region to get number of threads
    {
        if (omp_get_thread_num() == 0) nthreads = omp_get_num_threads();
    }
#endif

    // This part looks at sites inside the same monomer
    // Reset first indexes
    size_t fi_mon = 0;
    size_t fi_crd = 0;
    size_t fi_sites = 0;

    bool compute_pme = (ewald_alpha_ > 0 && use_pbc_);

    // override settings if ghost particles (big assumption?)
    // if calling this function, they really need to check still?
    if (!compute_pme && use_ghost && ewald_alpha_ > 0) compute_pme = true;

    if (compute_pme) {
        helpme::PMEInstance<double> pme_solver_;
        if (user_fft_grid_.size()) pme_solver_.SetFFTDimension(user_fft_grid_);
        // Compute the reciprocal space terms, using PME
        double A = box_ABCabc_[0];
        double B = box_ABCabc_[1];
        double C = box_ABCabc_[2];
        double alpha = box_ABCabc_[3];
        double beta = box_ABCabc_[4];
        double gamma = box_ABCabc_[5];

        int grid_A = pme_grid_density_ * A;
        int grid_B = pme_grid_density_ * B;
        int grid_C = pme_grid_density_ * C;

        if (mpi_initialized_) {
            pme_solver_.setupParallel(6, ewald_alpha_, pme_spline_order_, grid_A, grid_B, grid_C, -1, 0, world_,
                                      PMEInstanceD::NodeOrder::ZYX, proc_grid_x_, proc_grid_y_, proc_grid_z_);
        } else {
            pme_solver_.setup(6, ewald_alpha_, pme_spline_order_, grid_A, grid_B, grid_C, -1, 0);
        }

        pme_solver_.setLatticeVectors(A, B, C, alpha, beta, gamma, PMEInstanceD::LatticeType::XAligned);

        // N.B. these do not make copies; they just wrap the memory with some metadata
        auto coords = helpme::Matrix<double>(sys_xyz_.data(), natoms_, 3);

        auto params = helpme::Matrix<double>(sys_lj_long_range_.data(), natoms_, 1);
        // auto params = helpme::Matrix<double>(sys_c6_long_range_local_.data(), natoms_, 1);
        auto forces = helpme::Matrix<double>(sys_grad_.data(), natoms_, 3);
        std::vector<double> dummy_6vec(6, 0.0);
        auto rec_virial = helpme::Matrix<double>(dummy_6vec.data(), 6, 1);
        std::fill(sys_grad_.begin(), sys_grad_.end(), 0);
        double rec_energy = pme_solver_.computeEFVRec(0, params, coords, forces, rec_virial);

        const int num_procs = proc_grid_x_ * proc_grid_y_ * proc_grid_z_;

        // get virial
        if (calc_virial_) {
            virial_[0] += *rec_virial[0];
            virial_[1] += *rec_virial[1];
            virial_[2] += *rec_virial[3];
            virial_[4] += *rec_virial[2];
            virial_[5] += *rec_virial[4];
            virial_[8] += *rec_virial[5];

            virial_[3] = virial_[1];
            virial_[6] = virial_[2];
            virial_[7] = virial_[5];
        }

        // Resort forces from system order
        fi_mon = 0;
        fi_sites = 0;
        for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
            size_t ns = num_atoms_[fi_mon];
            size_t nmon = mon_type_count_[mt].second;
            for (size_t m = 0; m < nmon; m++) {
                size_t mns = m * ns;
                for (size_t i = 0; i < ns; i++) {
                    size_t inmon = i * nmon;
                    const double *result_ptr = forces[fi_sites + mns + i];
                    grad_[3 * fi_sites + 3 * inmon + 0 * nmon + m] -= result_ptr[0];
                    grad_[3 * fi_sites + 3 * inmon + 1 * nmon + m] -= result_ptr[1];
                    grad_[3 * fi_sites + 3 * inmon + 2 * nmon + m] -= result_ptr[2];
                }
            }
            fi_mon += nmon;
            fi_sites += nmon * ns;
        }
        // The Ewald self energy
        double prefac = std::pow(ewald_alpha_, 6) / 12.0;
        double self_energy = 0;
        for (const auto &lji : sys_lj_long_range_) {
            self_energy += lji * lji * prefac;
        }
        // With the entire system duplicated on all ranks, this over-counts by Nproc
        self_energy /= (double)num_procs;
        lj_energy_ += rec_energy + self_energy;
    }
}

void LennardJones::CalculateLennardJonesPMElocal(bool use_ghost) {
    int me;
#if HAVE_MPI == 1
    MPI_Comm_rank(world_, &me);
#else
    me = 0;
#endif

    lj_energy_ = 0.0;
    std::fill(phi_.begin(), phi_.end(), 0.0);
    // Parallelization
    size_t nthreads = 1;
#ifdef _OPENMP
#pragma omp parallel  // omp_get_num_threads() needs to be inside
                      // parallel region to get number of threads
    {
        if (omp_get_thread_num() == 0) nthreads = omp_get_num_threads();
    }
#endif

    // This part looks at sites inside the same monomer
    // Reset first indexes
    size_t fi_mon = 0;
    size_t fi_crd = 0;
    size_t fi_sites = 0;

    bool compute_pme = (ewald_alpha_ > 0 && use_pbc_);

    // override settings if ghost particles (big assumption?)
    // if calling this function, then shouldn't need to check this
    //    if(!compute_pme && use_ghost && ewald_alpha_ > 0) compute_pme = true;

    //    if (compute_pme) {
    helpme::PMEInstance<double> pme_solver_;
    if (user_fft_grid_.size()) pme_solver_.SetFFTDimension(user_fft_grid_);
    // Compute the reciprocal space terms, using PME
    double A = box_ABCabc_PMElocal_[0];
    double B = box_ABCabc_PMElocal_[1];
    double C = box_ABCabc_PMElocal_[2];
    double alpha = box_ABCabc_PMElocal_[3];
    double beta = box_ABCabc_PMElocal_[4];
    double gamma = box_ABCabc_PMElocal_[5];

    int grid_A = pme_grid_density_ * A;
    int grid_B = pme_grid_density_ * B;
    int grid_C = pme_grid_density_ * C;

    if (mpi_initialized_) {
        pme_solver_.setupParallel(6, ewald_alpha_, pme_spline_order_, grid_A, grid_B, grid_C, -1, 0, world_,
                                  PMEInstanceD::NodeOrder::ZYX, proc_grid_x_, proc_grid_y_, proc_grid_z_);
    } else {
        pme_solver_.setup(6, ewald_alpha_, pme_spline_order_, grid_A, grid_B, grid_C, -1, 0);
    }

    pme_solver_.setLatticeVectors(A, B, C, alpha, beta, gamma, PMEInstanceD::LatticeType::XAligned);

    // N.B. these do not make copies; they just wrap the memory with some metadata
    auto coords = helpme::Matrix<double>(sys_xyz_.data(), natoms_, 3);

#if 0
	// Zero property of particles outside local region

	// proc grid order hard-coded (as above) for ZYX NodeOrder
	
	int proc_x = me % proc_grid_x_;
	int proc_y = (me % (proc_grid_x_ * proc_grid_y_)) / proc_grid_x_;
	int proc_z = me / (proc_grid_x_ * proc_grid_y_);

	// include particles within local sub-domain and small halo region
	// this allows the full ghost region to be included for pairwise calculations,
	// but should exclude ghost monomers that are periodic images of local monomer

	double padding = cutoff_ * 0.5;
	double dx = A / (double) proc_grid_x_;
	double dy = B / (double) proc_grid_y_;
	double dz = C / (double) proc_grid_z_;

	double xlo =  proc_x    * dx - padding;
	double xhi = (proc_x+1) * dx + padding;
	
	double ylo =  proc_y    * dy - padding;
	double yhi = (proc_y+1) * dy + padding;
	
	double zlo =  proc_z    * dz - padding;
	double zhi = (proc_z+1) * dz + padding;

        std::vector<double> sys_c6_long_range_local_(sys_c6_long_range_.size(),0.0);
	for(int i=0; i<natoms_; ++i) sys_c6_long_range_local_[i] = sys_c6_long_range_[i];

	const int num_procs = proc_grid_x_ * proc_grid_y_ * proc_grid_z_;

	for(int i=0; i<natoms_; ++i) {
	  double x = coords(i,0);
	  double y = coords(i,1);
	  double z = coords(i,2);
	  
	  bool local = true;
	  if(x <= xlo || x > xhi) local = false;
	  if(y <= ylo || y > yhi) local = false;
	  if(z <= zlo || z > zhi) local = false;
	  
	  if(!local) sys_c6_long_range_local_[i] = 0.0;
	}
	
        auto params = helpme::Matrix<double>(sys_c6_long_range_local_.data(), natoms_, 1);
#else
    auto params = helpme::Matrix<double>(sys_lj_long_range_.data(), natoms_, 1);
#endif

    auto forces = helpme::Matrix<double>(sys_grad_.data(), natoms_, 3);
    std::vector<double> dummy_6vec(6, 0.0);
    auto rec_virial = helpme::Matrix<double>(dummy_6vec.data(), 6, 1);
    std::fill(sys_grad_.begin(), sys_grad_.end(), 0);
    double rec_energy = pme_solver_.computeEFVRec(0, params, coords, forces, rec_virial);

    // get virial
    if (calc_virial_) {
        virial_[0] += *rec_virial[0];
        virial_[1] += *rec_virial[1];
        virial_[2] += *rec_virial[3];
        virial_[4] += *rec_virial[2];
        virial_[5] += *rec_virial[4];
        virial_[8] += *rec_virial[5];

        virial_[3] = virial_[1];
        virial_[6] = virial_[2];
        virial_[7] = virial_[5];
    }

    // Resort forces from system order
    fi_mon = 0;
    fi_sites = 0;
    for (size_t mt = 0; mt < mon_type_count_.size(); mt++) {
        size_t ns = num_atoms_[fi_mon];
        size_t nmon = mon_type_count_[mt].second;
        for (size_t m = 0; m < nmon; m++) {
            size_t mns = m * ns;
            for (size_t i = 0; i < ns; i++) {
                size_t inmon = i * nmon;
                const double *result_ptr = forces[fi_sites + mns + i];
                grad_[3 * fi_sites + 3 * inmon + 0 * nmon + m] -= result_ptr[0];
                grad_[3 * fi_sites + 3 * inmon + 1 * nmon + m] -= result_ptr[1];
                grad_[3 * fi_sites + 3 * inmon + 2 * nmon + m] -= result_ptr[2];
            }
        }
        fi_mon += nmon;
        fi_sites += nmon * ns;
    }

    // The Ewald self energy
    double prefac = std::pow(ewald_alpha_, 6) / 12.0;
    double self_energy = 0;

    for (int i = 0; i < natoms_; ++i) self_energy += lj_long_range_[i] * lj_long_range_[i] * islocal_atom_[i];

    self_energy *= prefac;

    lj_energy_ += rec_energy + self_energy;

    //} // if(compute_pme)
}

std::vector<int> LennardJones::GetFFTDimension(int box_id) {
    double A, B, C, alpha, beta, gamma;
    bool compute_pme = true;
    if (box_id == 0) {
        if (box_ABCabc_.size()) {
            A = box_ABCabc_[0];
            B = box_ABCabc_[1];
            C = box_ABCabc_[2];
            alpha = box_ABCabc_[3];
            beta = box_ABCabc_[4];
            gamma = box_ABCabc_[5];
        } else
            compute_pme = false;

    } else if (box_id == 1) {
        if (box_ABCabc_PMElocal_.size()) {
            A = box_ABCabc_PMElocal_[0];
            B = box_ABCabc_PMElocal_[1];
            C = box_ABCabc_PMElocal_[2];
            alpha = box_ABCabc_PMElocal_[3];
            beta = box_ABCabc_PMElocal_[4];
            gamma = box_ABCabc_PMElocal_[5];
        } else
            compute_pme = false;
    }

    std::vector<int> fft_grid(3, -1);

    if (compute_pme) {
        int grid_A = pme_grid_density_ * A;
        int grid_B = pme_grid_density_ * B;
        int grid_C = pme_grid_density_ * C;

        helpme::PMEInstance<double> pme_solver_;
        if (user_fft_grid_.size()) pme_solver_.SetFFTDimension(user_fft_grid_);

        if (mpi_initialized_) {
            pme_solver_.setupParallel(1, ewald_alpha_, pme_spline_order_, grid_A, grid_B, grid_C, 1, 0, world_,
                                      PMEInstanceD::NodeOrder::ZYX, proc_grid_x_, proc_grid_y_, proc_grid_z_);
        } else {
            pme_solver_.setup(1, ewald_alpha_, pme_spline_order_, grid_A, grid_B, grid_C, 1, 0);
        }
        pme_solver_.setLatticeVectors(A, B, C, alpha, beta, gamma, PMEInstanceD::LatticeType::XAligned);

        fft_grid = pme_solver_.GetFFTDimension();
    }

    return fft_grid;
}

void LennardJones::SetFFTDimension(std::vector<int> grid) {
    // Easy things to check
    // If not, throw exception

    // vector of size 3

    if (grid.size() > 0 && grid.size() != 3) {
        std::string text = std::string("FFT grid != 3");
        throw CUException(__func__, __FILE__, __LINE__, text);
    }

    // elements are positive

    for (int i = 0; i < grid.size(); ++i)
        if (grid[i] < 1) {
            std::string text = std::string("FFT grid dimensions must be positive");
            throw CUException(__func__, __FILE__, __LINE__, text);
        }

    user_fft_grid_ = grid;
}

}  // namespace lj
