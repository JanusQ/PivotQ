[![MBX testing suite](https://github.com/paesanilab/MBX/actions/workflows/github-actions-mbx.yml/badge.svg)](https://github.com/paesanilab/MBX/actions/workflows/github-actions-mbx.yml)
[![codecov](https://codecov.io/gh/paesanilab/MBX/branch/master/graph/badge.svg?token=4OE0CPMHGR)](https://codecov.io/gh/paesanilab/MBX)
[![Homepage](https://img.shields.io/badge/google%20groups-mbx--users-green)](https://groups.google.com/g/mbx-users)



# MBX v1.4.0
MBX: A many-body energy and force calculator for data-driven many-body simulations.
[J. Chem. Phys. 159, 054802 (2023)](https://doi.org/10.1063/5.0156036)


MBX is a C++ software that can either be used as a standalone software for calculating energies and forces of MB-nrg potential energy functions (PEFs) for the molecular systems of interest or interfaced with external molecular dynamics engines to perform classical and quantum simulations of the molecular system of interest across different thermodynamic states and phases, in both periodic and non-periodic conditions, using the corresponding MB-nrg PEFs.
The current version of MBX provides interfaces to LAMMPS (https://www.lammps.org) and i-PI (http://ipi-code.org) which allow for performing classical and path-integral molecular dynamics simulations using MB-nrg PEFs.
For details on the MB-pol and MB-nrg PEFs, please visit: https://paesanigroup.ucsd.edu/software/mbx.html.

MBX is periodically updated with performance improvements and the addition of other MB-nrg PEFs. For any questions about MBX, installation issues, or general usage inquiries, please use the MBX Google Group: https://groups.google.com/g/mbx-users.

## Compilation and Installation
The following requirements need to be fulfilled in order to successfully install the software:
- g++/gcc v9.3 or higher
- icpx/icx v2020 or higher [optional]
- FFTW libraries
- **Read the entire README before doing anything!**

The following requirements are optional, depending on how you plan to use MBX:
- MPI compilers [sometimes used for MBX+LAMMPS]
- GSL libraries [needed only for normal_modes executable]

### Compilation
MBX has different compilation instructions depending on how you plan to use it:
- For use with **i-PI**, **Python**, **Fortran**, or **standalone**, perform a [basic installation](#basic-installation-of-mbx-for-use-with-i-pi-python-fortran-or-standalone-not-lammps)
- For use with **LAMMPS**, perform an [alternative MBX_MPI installation](#lammps)

#### Basic installation of MBX (for use with i-PI, Python, ASE, Fortran, or standalone. **NOT LAMMPS**)
```console
git clone https://github.com/paesanilab/MBX.git
cd MBX/

autoreconf -fi
./configure
make && make install

export MBX_HOME=$(pwd) # optional
```

`./configure` has additional flags and options if you want to customize your installation:
- `CXX=` if you want to use a different compiler than the system default. Popular options include `CXX=icpx` or `CXX=g++`
- `--enable-shared` if you want to also compile MBX as a shared library. This is **required for using MBX with Python**.
- `--enable-debug` for debugging using GDB.
- `--enable-verbose` will turn on additional logging to the console.
- `--disable-optimization` will disable compiler optimizations. This is **not recommended** unless you are debugging.
- `--help` to see additional configuration options

After performing basic installation, you should [run the unit tests](#testing) to make sure everything is working properly.

#### [Alternative installation of MBX_MPI](#lammps) (**LAMMPS only**)
If you want to use MBX with LAMMPS, instead [skip to this section about the LAMMPS plugin](#lammps). This special installation using MPI is **only compatible with LAMMPS** and is incompatible with i-PI, Python, Fortran or standalone usage. If you need to use any of these other plugins, perform a separate [basic installation](#basic-installation-of-mbx-for-use-with-i-pi-python-fortran-or-standalone-not-lammps) in a different directory.

## Testing
After [basic installation](#basic-installation-of-mbx-for-use-with-i-pi-python-fortran-or-standalone-not-lammps), running the unit tests is highly recommended. Run the following commands to run the tests:
```
make check
```
All tests must pass. If you encounter any errors, please report them in the [MBX Google Group](https://groups.google.com/g/mbx-users).

Tests will fail if using an MPI compiler instead of `g++`/`icpc`, such as if you performed alternative installation with MBX_MPI with LAMMPS. Please instead perform [basic installation](#basic-installation-of-mbx-for-use-with-i-pi-python-fortran-or-standalone-not-lammps) first with `g++`/`icpc` and then run the tests.

## JSON File
To make life easier for you, a JSON configuration file must be used to pass all the information that MBX needs. Usually, one does not need to change anything except a couple of options. In any case, all the options of the json file are explained below.

The JSON file template is the following:
```
{
   "Note" : "This is a  MBX v1.0.0 configuration file",
   "MBX" : {
       "box" : [21.0,0.0,0.0,0.0,21.0,0.0,0.0,0.0,21.0],
       "realspace_cutoff"   : 9.0,
       "twobody_cutoff"   : 9.0,
       "threebody_cutoff" : 7.0,
       "dipole_tolerance" : 1E-08,
       "dipole_max_it"    : 100,
       "dipole_method"     : "cg",
       "alpha_ewald_elec" : 0.6,
       "grid_density_elec" : 2.5,
       "spline_order_elec" : 6,
       "alpha_ewald_disp" : 0.6,
       "grid_density_disp" : 2.5,
       "spline_order_disp" : 6,
       "ignore_2b_poly" : [],
       "ignore_3b_poly" : []
   } ,
   "i-pi" : {
       "localhost" : "localhost3",
       "port" : 34567
   }
}
```
In this file:
- `box` is either a 9 element list, with the 3 vectors of the box: `[ax, ay, az, bx, by, bz, cx, cy, cz]` or an empty list `[]` if one wants to run gas-phase calculations.
- `realspace_cutoff` is the distance at which the dispersion, Lennard-Jones, and electrostatics interactions will switch from the real space to the reciprocal space (Particle-Mesh Ewald). Usually a value of about `9.0` is good for calculations in periodic boundary conditions. In gas phase calculations, this should be set to a large number that exceeds the farthest interatomic distance in your system so that all interactions are computed in the real space. For backwards compatibility reasons, if `realspace_cutoff` is not specified, then it will be set to the `twobody_cutoff`.
- `twobody_cutoff` is the cutoff for the 2-body polynomials. If only water is used, one can set that to `6.5`, but if alkali metal ions or halides are used, it should be set to the maximum cutoff in any of the dimers used (`9.0`).
- `threebody_cutoff` is the cutoff for the 3-body polynomials. If only water is used, one can set that to `4.5`, but if alkali metal ions or halides are used, it should be set to the maximum cutoff in any of the trimers used (`7.0`).
- `dipole_tolerance` is the tolerance accepted for the induced dipoles iterative calculation. From one iteration to the other one, |mu(i,t+1) - mu(i,t)|^2 < dipole tolerance for any i. A value of `1E-08` is usually small enough. However, if the dipole solver used is aspc, the magnitude of the tolerance may have to be decreased up to `1E-10` or `1E-12`. It is recommended to run a few thousand steps using aspc and cg for the dipole solver, and decide which is the dipole tolerance needed.
- `dipole_max_it` is the maximum number of iterations allowed in the dipole iterative method calculation. If the number of iterations exceeds this value, MBX will throw an error message saying that the dipoles have diverged.
- `dipole_method` is the method adopted to calculate the induced dipoles. Current options are `iter` (iterative), `cg` (conjugate gradient, faster than iter), and `aspc` (always stable predictor-corrector). `aspc` is only suitable for simulations. Only `cg` and `aspc` are currently available in LAMMPS.
- `alpha_ewald_{elec/disp}` is the alpha used in the reciprocal space. It should be set to `0.0` when running gas-phase calculations/simulations.
- `grid_density_{elec/disp}` is the Ewald grid points density.
- `spline_order_{elec/disp}` is the order of the splines used for interpolation.
- `ignore_2b_poly` a list of 2 element lists with the monomer pairs for which the 2-body polynomials will not be calculated. Example: `"ignore_2b_poly" : [["na+","h2o"]]`
- `ignore_3b_poly` has a similar format as ignore_2b_poly, but with the difference that the list is a list of 3-element list. If a set of three monomer types is specified in this list, MBX won't calculate the 3-body polynomials for that given trimer. Example: `"ignore_3b_poly" : [["na+","h2o","h2o"]]`
- `localhost` is the name of the socket. It MUST match the name in the XML file, otherwise it will send an error saying that the socket was not found.
- `port` is used when interfacing with i-pi. It is the port that will hold the socket. Should be greater than `34500`.

## Main executables
After installation, there will be the main executables in `$MBX_HOME/bin/`.
- `single_point` will return the energy (Binding Energy) in kcal/mol for a given configuration. One can have multiple systems in the nrg file, and single point will return the energies of each one of them. If `PRINT_GRADS` is manually enabled in the source code in (`$MBX_HOME/src/main/single_point.cpp`) it will also print the gradients.
- `optimize` will optimize a given configuration. You can optimize a single nrg system, or pass an XYZ file with a set of configurations, in which all of them will be optimized.
- `mb_decomp` will compute energies for subsystems for the given system(s), then performs many-body decomposition and prints the n-body contribution for all subsystems. If the flag to skip many-body decomposition ("`-e`") is activated, it instead prints the binding energy for all subsystems.
- `order_frames` will compute the energies for a given list of configurations from the XYZ file, and rearranges the configuration frames in the order of increasing energy.
- `normal_modes` will compute the normal modes for an optimized nrg file. Requires the GSL library.

## Examples

Examples for most implemented PEFs can be found in `examples/PEFs`.
Example calls with C++, Fortran, and Python can be found in the various sub-folders in that directory.

## Associated Publications and How to Cite

The following papers describe the features in various MBX releases. Please cite them when using MBX:
- MBX v1.0:
  * [J. Chem. Phys. 159, 054802 (2023)](https://doi.org/10.1063/5.0156036)
- MBX v1.1 and v1.2:
  * [J. Chem. Theory Comput. 21, 1838 (2025)](https://doi.org/10.1021/acs.jctc.4c01333)
- MBX v1.3 and v1.4:
  * [ChemRxiv. 02 July 2026.](https://doi.org/10.26434/chemrxiv.15005580/v1)

Each PEF implemented in MBX is associated with one or more publications detailing their development and applications. Please cite the following manuscripts where you use the associated PEFs:
- MB-pol for water: **\"h2o\"**
  * [J. Chem. Theory Comput. 9, 5395 (2013)](https://doi.org/10.1021/ct400863t)
  * [J. Chem. Theory Comput. 10, 1599 (2014)](https://doi.org/10.1021/ct500079y)
  * [J. Chem. Theory Comput. 10, 2906 (2014)](https://doi.org/10.1021/ct5004115)
  * [J. Chem. Phys. 145, 194504 (2016)](https://doi.org/10.1063/1.4967719)
  * [Acc. Chem. Res. 49, 1844 (2016)](https://doi.org/10.1021/acs.accounts.6b00285)
- MB-nrg PEFs for alkali-metal ions in water: **\"li+**, **\"na+**, **\"k+**, **\"rb+**, **\"cs+\"**
  * [J. Chem. Phys. 147, 161715 (2017)](https://doi.org/10.1063/1.4993213)
  * [J. Phys. Chem. A 122, 5811 (2018)](https://doi.org/10.1021/acs.jpca.8b04106)
  * [J. Phys. Chem. Lett. 10, 406 (2019)](https://doi.org/10.1021/acs.jpclett.8b03829)
  * [J. Chem. Phys. 153, 044306 (2020)](https://doi.org/10.1063/5.0013101)
  * [J. Chem. Theory Comput. 16, 3055 (2020)](https://doi.org/10.1021/acs.jctc.0c00082)
  * [J. Phys. Chem. B. 126, 9349 (2022)](https://doi.org/10.1021/acs.jpcb.2c05674)
- MB-nrg PEFs for halide ions in water: **\"f-**, **\"cl-**, **\"br-**, **\"i-\"**
  * [J. Chem. Theory Comput. 12, 2698 (2016)](https://doi.org/10.1063/5.0059445)
  * [J. Chem. Phys. 148, 102321 (2018)](https://doi.org/10.1063/1.5005540)
  * [J. Comp. Theory. Comput. 15, 2983 (2019)](https://doi.org/10.1021/acs.jctc.9b00064)
  * [Nat. Chem. 11, 367 (2019)](https://www.nature.com/articles/s41557-019-0220-2)
  * [J. Phys. Chem. Lett. 10, 2823 (2019)](https://doi.org/10.1021/acs.jpclett.9b00899)
  * [J. Phys. Chem. A 123, 2843 (2019)](https://doi.org/10.1021/acs.jpca.9b00816)
  * [Adv. Phys. X 4, 1631212 (2019)](https://doi.org/10.1080/23746149.2019.1631212)
  * [J. Chem. Phys. 155, 064502 (2021)](https://doi.org/10.1063/5.0059445)
  * [J. Phys. Chem. B 126, 8266 (2022)](https://doi.org/10.1021/acs.jpcb.2c04698)
- MB-nrg PEFs for CO<sub>2</sub> and CO<sub>2</sub>/H<sub>2</sub>O mixtures: **\"co2\"**
  * [J. Chem. Theory Comput. 16, 2246 (2020)](https://doi.org/10.1021/acs.jctc.9b01175)
  * [J. Chem. Phys. 156, 104503 (2022)](https://doi.org/10.1063/5.0080061)
- MB-nrg PEFs for CH<sub>4</sub> and CH<sub>4</sub>/H<sub>2</sub>O mixtures: **\"ch4\"**
  * [J. Phys. Chem. B 124, 11207 (2020)](https://doi.org/10.1021/acs.jpcb.0c08728)
  * [J. Chem. Phys. 156, 194504 (2022)](https://doi.org/10.1063/5.0089773)
- MB-nrg PEF for N<sub>2</sub>O<sub>5</sub> solvated in water: **\"n2o5\"**
  * [J. Chem. Theory Comput. 17, 3931 (2021)](https://doi.org/10.1021/acs.jctc.1c00069)
- MB-nrg PEF for NH<sub>3</sub>: **\"nh3\"**
  * [J. Chem. Phys. 155, 124801 (2021)](https://doi.org/10.1063/5.0063198)
- MB-nrg PEF for water based on the PBE-D3 functional: **\"mbpbe\"**
  * [J. Chem. Theory Comput. 17, 5635 (2021)](https://doi.org/10.1021/acs.jctc.1c00541)

The potentials associated with the following publications are not distributed with MBX by default, but are available on other branches or by request:

- MB-nrg PEFs for water using the scan functional as the reference: **\"h2o-scan\"**, **\"h2o-dcscan\"**
  * [Nat. Commum. 12, 6359 (2021)](https://doi.org/10.1038/s41467-021-26618-9)
  * [J. Chem. Theory Comput. 18, 3410 (2022)](https://doi.org/10.1021/acs.jctc.2c00050)
  * [J. Chem. Theory Comput. 18, 4745 (2022)](https://doi.org/10.1021/acs.jctc.2c00313)
  * these PEFs are available on the [MB-DFT](https://github.com/paesanilab/MBX/tree/mbx_with_mb-dft_1.2) branch of MBX.

- MB-nrg PEFs for solvated ions using the scan functional as the reference: **\"cl-scan\"**, **\"cl-dcscan\"**, **\"na+scan\"**, **\"na+dcscan\"**
  * [J. Chem. Phys. 159, 181101 (2023)](https://doi.org/10.1063/5.0174577)
  * these PEF are available on the [MB-DFT](https://github.com/paesanilab/MBX/tree/mbx_with_mb-dft_1.2) branch of MBX.
- MB-nrg PEFs for water using the DM21 functional as the reference: 
  * [J. Chem. Phys. 156, 161103 (2022)](https://doi.org/10.1063/5.0090862)
  * this PEF is available by request.
- MB-nrg PEFs for water using the various other DFT functionals as the reference: 
  * [J. Chem. Theory Comput. 18, 3410 (2022)](https://doi.org/10.1021/acs.jctc.2c00050)
  * [Chem. Phys. Rev. 4, 011301 (2023)](https://doi.org/10.1063/5.0129613)
  * these PEFs are available by request.
- MB-pol(2023), a family of PEFs which improve on the original MB-pol PEF:
  * [J. Chem. Theory Comput. 19, 3551 (2023)](https://doi.org/10.1021/acs.jctc.3c00326)
  * these PEFs are available on the [MB-pol(2023)](https://github.com/PhilipZhu/MBX/tree/mbpol23/src) branch of MBX.
- MB-nrg PEF for water using a permutationally invariant fourier series: **\"h2o_pifs\"**
  * [J. Chem. Theory Comput. 21, 6950 (2025)](https://doi.org/10.1021/acs.jctc.5c00407)
  * this PEF is available on the [PIFs](https://github.com/PhilipZhu/MBX/tree/PIFS) branch of MBX.
- MB-nrg PEF for solvated NMA: **\"nma\"**
  * [J. Chem. Theory Comput. 19, 4308 (2023)](https://doi.org/10.1021/acs.jctc.3c00271)
  * this PEF is available by request.
  * Note: the nma potential on the master branch does *not* correspond to this publication, and will be the subject of a future work.
- MB-nrg PEF for linear alkanes:
  * [J. Chem. Theory Comput. 19, 4494 (2023)](https://doi.org/10.1021/acs.jctc.2c00645)
  * this PEF is available by request.
- MB-nrg PEF for polyalanine:
  * [J. Chem. Theory Comput. 21, 6194 (2025)](https://doi.org/10.1021/acs.jctc.5c00474)
  * [J. Chem. Theory Comput. 21, 10574 (2025)](https://doi.org/10.1021/acs.jctc.5c01335)
  * this PEF is available by request.


Below is a (non-exhaustive) list of publications which apply, validate, or otherwise use various MB-nrg PEFs through MBX:
- Realistic phase diagram of water from “first principles” data-driven quantum simulations
  * [Nat. Commun. 14, 3349 (2023)](https://doi.org/10.1038/s41467-023-38855-1)
- Hydration Free Energies of Alkali Metal and Halide Ions from Data-Driven Many-Body Potentials
  * [J. Chem. Theory Comput. 22, 4688 (2026)](https://doi.org/10.1021/acs.jctc.6c00391)
- Density-Functionalized QM/MM Delivers Chemical Accuracy For Solvated Systems
  * [J. Chem. Theory Comput. 21, 10340 (2026)](https://doi.org/10.1021/acs.jctc.5c01440)
- Density-Functionalized QM/MM Delivers Chemical Accuracy For Solvated Systems
  * [J. Chem. Theory Comput. 21, 10340 (2026)](https://doi.org/10.1021/acs.jctc.5c01440)
- Sub-nanometer Confinement Suppresses Autoionization of Water
  * [J. Am. Chem. Soc. 147, 25167 (2025)](https://doi.org/10.1021/jacs.5c08273)

The following review papers present an overview of MB-pol and MB-nrg style PEFs:
- From Potentials to Properties: Data-Driven Many-Body Simulations of Water and Aqueous Systems.
  * [Annu. Rev. Phys. Chem. 77, 321 (2026)](https://doi.org/10.1146/annurev-physchem-082423-115133)
- Current Status of the MB-pol Data-Driven Many-Body Potential for Predictive Simulations of Water Across Different Phases.
  * [J. Chem. Theory Comput. 20, 9269 (2024)](https://doi.org/10.1021/acs.jctc.4c01005)

## Interfaces
### Fortran90 and Python
In `${MBX_HOME}/examples/PEFs` there are sample scripts on how to use MBX called from Fortran90 and Python. Please remember to update the `LD_LIBRARY_PATH` variable and, if using python, the `PYTHONPATH` variable.
```console
export LD_LIBRARY_PATH=$MBX_HOME/lib/:$LD_LIBRARY_PATH
export PYTHONPATH=${PYTHONPATH}:${MBX_HOME}/plugins/python/mbx
```

### ASE
An ASE calculator plugin is available in `plugins/ase`. See `plugins/ase/README.md` for install and usage.


### LAMMPS
MBX is an official LAMMPS package (https://docs.lammps.org/pair_mbx.html),
and needs to be installed using the [LAMMPS CMake build-chain](https://docs.lammps.org/Build_cmake.html):

```console
git clone -b develop https://github.com/lammps/lammps.git
cd lammps

cmake -S cmake -B build -C ./cmake/presets/basic.cmake -D PKG_MBX=yes -D PKG_EXTRA-PAIR=yes
cmake --build build --parallel 4                   # compilation (can use higher --parallel on powerful computers)
```
This special installation using MPI is **only compatible with LAMMPS** and is incompatible with i-PI, Python, Fortran or standalone usage. If you need to use any of these other MBX plugins, perform a separate [basic installation](#basic-installation-of-mbx-for-use-with-i-pi-python-fortran-or-standalone-not-lammps) in a different directory.

Additional LAMMPS build options are available, such as using a different compiler or enabling additional packages. Please refer to the [LAMMPS CMake build documentation](https://docs.lammps.org/Build_basics.html) for more information.

Examples for MBX+LAMMPS simulations are located in `$MBX_HOME/plugins/lammps/examples/`. Also see the LAMMPS documentation for more information about how to use MBX with LAMMPS: https://docs.lammps.org/pair_mbx.html.

For any questions, please use the MBX Google Group: https://groups.google.com/g/mbx-users.


### i-PI
This software is already interfaced with i-PI. In order to run molecular dynamics using the MB-nrg PEFs, you will need to install i-PI first.
```console
git clone https://github.com/i-pi/i-pi.git
```
 Before continuing with this, make sure i-PI is working. If you have any problems with the i-PI installation, you can ask a question in [the i-pi-user forum](https://groups.google.com/forum/#!forum/ipi-users). If you want to skip the testing (PROCEED AT YOUR OWN RISK), you can skip testing i-PI and assume it works.

After making sure that i-PI is working on your machine and having [compiled MBX](#basic-installation-of-mbx-for-use-with-i-pi-python-fortran-or-standalone-not-lammps), you can use the i-PI driver located in `$MBX_HOME/bin/ipi_driver` to run MD using i-PI. To confirm that the driver is working, go to the i-PI examples folder in MBX:
```console
cd $MBX_HOME/plugins/i-pi/examples/molecular_dynamics/gas_phase/3h2o/100K/1-nvt
```

This folder contains five files:
- `config.xyz` is the input for the coordinates for i-PI, while `config.nrg` is the input format for MBX. These two files `xyz` and `nrg` are related, so if you make any changes to the xyz file you must correspondingly update the nrg file using `$MBX_HOME/scripts/format_conversion config.xyz`
- `config.xml` is the i-PI input file. This simulation will run an NVT MD at 100K. Refer to the i-pi user manual for more information.
- `mbx.json` is the MBX configuration file
- `run_i-pi.sh` will run the test. Make sure you `source env.sh` in the i-PI folder before running the test, or most likely it will fail.

These should initialize i-PI and start the simulation. Once the simulation is completed, terminate the i-pi instance and then run the NVE simulation in `$MBX_HOME/plugins/i-pi/examples/molecular_dynamics/gas_phase/3h2o/100K/2-nve`.
```
cd $MBX_HOME/plugins/i-pi/examples/molecular_dynamics/gas_phase/3h2o/100K/2-nve
cp ../1-nvt/RESTART ./config.xml
./run_i-pi.sh
```

There are more tests for other types of simulations, including condensed phase simulations and replica-exchange simulations. For more information about what kind of simulations can i-PI run, please refer to the i-PI user manual.


## Coverage
The unit tests implemented should cover a big part of the code. This sunburst graph gives an idea of the coverage from top (center) to bottom (periphery). Our goal is to keep it as green as possible, being green good coverage, and red bad coverage.
<p align="center">
  <img src="https://codecov.io/gh/paesanilab/MBX/branch/master/graphs/sunburst.svg?token=4OE0CPMHGR" />
</p>


## Acknowledgements

The development of MBX is supported by the U.S. National Science Foundation through award no. 2311260, “Frameworks: Data-Driven Software Infrastructure for Next-Generation Molecular Simulations.”

Information about this award can be found at the following link: https://www.nsf.gov/awardsearch/show-award/?AWD_ID=2311260 .
